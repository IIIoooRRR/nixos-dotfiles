{config, pkgs, ...}:
{
 nix.settings = { 
      substituters = [
        "https://cache.nixos.org"
      ];
      
      trusted-substituters = [
        "https://cache.nixos.org"
      ];
      
      
      max-jobs = 4;
      cores = 4;
    };

}
