{config, lib, pkgs, ...}:
{
 i18n = {
    defaultLocale = "en_US.UTF-8";
    supportedLocales = [
      "en_US.UTF-8/UTF-8"
      "ru_RU.UTF-8/UTF-8"
    ];
    # supportedLocales = all;
  };
environment.systemPackages = with pkgs; [
    #visual
    libGL
    mesa
    wayland
    wayland-protocols
    glib
    gtk3
    libxkbcommon
    xdg-desktop-portal-gtk
    xwayland-satellite
   #design      
    swaybg          
    wl-clipboard
    zsh
    fastfetch
    imagemagick
    lavat
    cava
    peaclock
    #utils
    git
    curl
    nftables
    yazi
    kitty
    steam-run
    libwebp
    qbittorrent
    iptables
    blockbench
    onlyoffice-desktopeditors
    #comfort
    waybar
    fuzzel
    mako  #уведы
    swaylock
    #social
    telegram-desktop
    firefox
    vesktop   
   #screen
    grim
    slurp
    brightnessctl 
    wireplumber
    #games
    waydroid
    umu-launcher
    #programming
    jdk21 jdk17 jdk25
    go_1_27
    gcc
    gnumake
    tree
    neovim
    delve
    gopls
    gotools    
    flutter
    android-tools
    android-studio
#music
	(ncmpcpp.override { visualizerSupport = true; })	
];
networking.nftables.enable = true;
  programs.git = {
    enable = true;
    lfs.enable = true;  
  };
services.flatpak.enable = true;


nixpkgs.config.packageOverrides = super: {
    openldap = super.openldap.overrideAttrs (old: {
      doCheck = false;
      doInstallCheck = false;
    });
  };


virtualisation.waydroid.enable = true;
programs.dconf.enable = true;
systemd.user.services.niri.enableDefaultPath = false;
xdg.portal = {
  enable = true;
  extraPortals = [
    pkgs.xdg-desktop-portal-gnome
    pkgs.xdg-desktop-portal-gtk
    pkgs.xdg-desktop-portal-wlr
  ];
   config = {
    common.default = [ "gtk" ];
    niri = {
      "org.freedesktop.impl.portal.ScreenCast" = [ "gnome" ];
      "org.freedesktop.impl.portal.Screenshot" = [ "gnome" ];
    };
  };
};
}
