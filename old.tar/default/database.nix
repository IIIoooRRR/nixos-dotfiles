{config, pkgs, ...}:
{
  services.postgresql = {
    enable = false;
    enableTCPIP = true;
    package = pkgs.postgresql_16;

    ensureDatabases = [ "kezess" ];

    authentication = pkgs.lib.mkOverride 10 ''
      local all all trust
      host all all 127.0.0.1/32 trust
      host all all ::1/128 trust
    '';
  };
}
