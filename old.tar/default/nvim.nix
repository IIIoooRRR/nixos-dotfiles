{ config, pkgs, ... }:

{
  home-manager.users.kezess = {

    home.file.".config/nvim/init.lua".text = ''
      
      local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
      if not vim.loop.fs_stat(lazypath) then
        vim.fn.system({
          "git",
          "clone",
          "--filter=blob:none",
          "https://github.com/folke/lazy.nvim.git",
          "--branch=stable",
          lazypath,
        })
      end
      vim.opt.rtp:prepend(lazypath)

         
      require("lazy").setup({
        {
          "AstroNvim/AstroNvim",
          version = "^4",
          import = "astronvim.plugins",
          config = function()
            require("astronvim").setup({
              mason = { enabled = false },
              mason_lspconfig = { enabled = false },
              
              lsp = {
                servers = {
                  gopls = {},
                  rust_analyzer = {
                    settings = {
                      ["rust-analyzer"] = {
                        checkOnSave = { command = "clippy" }
                      }
                    }
                  }
                }
              },
              
              plugins = {
                {
                  "nvim-treesitter/nvim-treesitter",
                  opts = { ensure_installed = { "rust", "go" } }
                }
              }
            })
          end
        }
      })

      
      vim.opt.number = true
      vim.opt.relativenumber = true
      vim.opt.tabstop = 2
      vim.opt.shiftwidth = 2
      vim.opt.expandtab = true
    '';

    home.sessionVariables = {
      EDITOR = "nvim";
      VISUAL = "nvim";
    };
  };
}
