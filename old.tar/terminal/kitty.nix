{config, pkgs, ...}:
{
home-manager.users.kezess = {
  home.file.".config/kitty/kitty.conf".text = ''
    background_opacity 0.85
    dynamic_background_opacity yes
    font_size 11
    font_family JetBrains Mono
    background #141318
    foreground #cdd6f4
    color0 #45475a
    color8 #585b70
    color1 #f38ba8
    color9 #f38ba8
    color2 #a6e3a1
    color10 #a6e3a1
    color3 #f9e2af
    color11 #f9e2af
    color4 #89b4fa
    color12 #89b4fa
    color5 #cba6f7
    color13 #cba6f7
    color6 #94e2d5
    color14 #94e2d5
    color7 #bac2de
    color15 #a6adc8
    cursor_shape beam
    hide_window_decorations no
    map ctrl+shift+z new_window
    map ctrl+shift+t new_tab
    map ctrl+shift+q close_tab
  '';
  };
}
