# Edit this configuration file to define what should be installed on
# your system. Help is available in the configuration.nix(5) man page
# and in the NixOS manual (accessible by running ‘nixos-help’).
{ config, pkgs, lib, ... }:

let
  home-manager = builtins.fetchTarball {
    url = "https://github.com/nix-community/home-manager/archive/release-25.11.tar.gz";
};
in
{
  nixpkgs.config.allowUnfree = true;

  imports = [
  ./hardware-configuration.nix
  ./default/user.nix
  ./default/packages.nix
  ./default/docker.nix
  ./default/database.nix
  ./default/nvim.nix
  ./system/steam.nix
  ./system/system.nix
  ./zapret.nix
   (import "${home-manager}/nixos")
  ./display/niri.nix
  ./display/write.nix
  ./display/cursor.nix
  ./display/mako.nix
  ./terminal/zsh.nix
  ./terminal/fastfetch.nix
  ./terminal/kitty.nix
  ./music/ncmpcpp.nix
  ./music/visual.nix
  ];
  home-manager = {
    useGlobalPkgs = true;
    useUserPackages = true;
    users.kezess = { config, pkgs, lib, ... }: {
      home.stateVersion = "25.11";
      programs.home-manager.enable = true;
      home.enableNixpkgsReleaseCheck = false;
    };
  };
  boot.loader.systemd-boot.enable = true;
  boot.loader.efi.canTouchEfiVariables = true;
  boot.kernelPackages = pkgs.linuxPackages_latest;

  nix.settings.experimental-features = [ "nix-command" "flakes" ];
  console.keyMap = "ru";
  services.xserver.xkb.layout = "us,ru";
  services.xserver.xkb.options = "grp:alt_shift_toggle";


  networking.hostName = "nixos";
  networking.networkmanager.enable = true;
  networking.firewall.checkReversePath = false;
  networking.extraHosts = ''
  # Базовые записи по умолчанию
  127.0.0.1 localhost
  ::1       localhost

  127.0.0.1 animori.local minio.animori.local s3.animori.local mail.animori.local supervisord-monitor.animori.local rabbitmq.animori.local animori-backend
'';
  time.timeZone = "Asia/Novosibirsk";

    i18n.defaultLocale = "en_US.UTF-8";
  i18n.extraLocaleSettings = {
    LC_ADDRESS = "ru_RU.UTF-8";
    LC_IDENTIFICATION = "ru_RU.UTF-8";
    LC_MEASUREMENT = "ru_RU.UTF-8";
    LC_MONETARY = "ru_RU.UTF-8";
    LC_NAME = "ru_RU.UTF-8";
    LC_NUMERIC = "ru_RU.UTF-8";
    LC_PAPER = "ru_RU.UTF-8";
    LC_TELEPHONE = "ru_RU.UTF-8";
    LC_TIME = "ru_RU.UTF-8";
  };

  services.printing.enable = true;

  services.pulseaudio.enable = false;
  security.rtkit.enable = true;
  services.pipewire = {
    enable = true;
    alsa.enable = true;
    alsa.support32Bit = true;
    pulse.enable = true;
  };

  services.getty.autologinUser = "kezess";
  programs.yazi.enable = true;
     programs.zsh = {
    enable = true;
    promptInit = ''
      fastfetch
      
      if [ -z "$DISPLAY" ] && [ "$XDG_VTNR" = 1 ]; then
        exec niri
      fi
    '';
  };
  programs.niri.enable = true;
  security.polkit.extraConfig = ''
  polkit.addRule(function(action, subject) {
    if (
      (action.id == "org.freedesktop.login1.reboot" ||
       action.id == "org.freedesktop.login1.power-off") &&
      subject.isInGroup("wheel")
    ) {
      return polkit.Result.YES;
    }
  });
'';

  nix.settings = {
  substituters = [
    "https://mirrors.tuna.tsinghua.edu.cn/nix-channels/store"
    "https://cache.nixos.org"
  ];

  trusted-public-keys = [
    "cache.nixos.org-1:6NCHdD59X431o0gWypbMrAURkbJ16ZPMQFGspcDShjY="
  ];
};
  nix.settings.auto-optimise-store = true;
  programs.nix-ld.enable = true;
programs.nix-ld.libraries = with pkgs; [
  tree-sitter
];  
system.stateVersion = "25.11";
  
}

