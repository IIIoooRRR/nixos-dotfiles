{
  description = "zapreeet";
  nixConfig = {
    pure-eval = false;
  };
  inputs = {
  nixpkgs.url = "github:nixos/nixpkgs/nixos-26.05";
  zapret-discord-youtube.url = "github:kartavkun/zapret-discord-youtube";
  };
  outputs = { self, nixpkgs, zapret-discord-youtube}: {
    nixosConfigurations.nixos = nixpkgs.lib.nixosSystem {
      system = "x86_64-linux";
      modules = [
        ./configuration.nix
        ./zapret.nix

        zapret-discord-youtube.nixosModules.withTestTools
      ];
    };
  };
}
